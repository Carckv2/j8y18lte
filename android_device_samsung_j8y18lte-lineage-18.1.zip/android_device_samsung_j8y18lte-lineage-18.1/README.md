=====================================

Basic   | Spec Sheet
-------:|:-------------------------
CPU     | Octa-core 1.8GHz Cortex-A53
CHIPSET | Qualcomm SDM450 Snapdragon 450 (14 nm) msm8953
GPU     | Adreno 506
Memory  | 3GB/4GB
Shipped Android Version | Android 8.0 with TouchWiz Essence
Upgradable To | Android 10 (OneUI 2.0)
Storage | 32GB/64GB
MicroSD | Up to 256 GB
Battery | 3500 mAh Li-Ion (non-removable)
Display | 720 x 1480 pixels, 18.5:9 ratio
Rear Camera  | 16.0 MP, 5.0 MP, LED flash
Front Camera | 16.0 MP, LED flash
Release Date | July 2018

![Samsung Galaxy J8](https://fdn2.gsmarena.com/vv/pics/samsung/samsung-galaxy-j8-j800-5.jpg)

